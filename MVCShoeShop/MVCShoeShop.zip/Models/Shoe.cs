﻿namespace MVCShoeShop.Models
{
    public class Shoe
    {
        public int Id { get; set; }

        public string Color {  get; set; }

        public int Size { get; set; }
    }
}
