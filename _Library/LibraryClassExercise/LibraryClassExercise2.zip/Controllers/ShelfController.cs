﻿using LibraryClassExercise.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using LibraryClassExercise.Models;

namespace LibraryClassExercise.Controllers
{
    public class ShelfController : Controller
    {
        // GET: ShelvesController
        public ActionResult List()
        {
            return View();
        }

        // GET: ShelvesController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ShelvesController/Create
        // Take into account that the VIEW must receive:
        // - Shelf object
        // - Library Id
        // 
        // 2 Modes:
        // - Create new (blank)
        // - Create new (failed validations - existing object)
        [Route("/Shelf/Create/{libraryId}")]
        public ActionResult Create(int libraryId)
        {
            // 1. Completely first time - NEW object
            LibraryShelf ls = new LibraryShelf()
            {
                // Extract id from Route
                Shelf = new Shelf(),
                LibraryId = libraryId
            };

            // 2. Second time, after validations
            // ...

            return View(ls);
        }

        // POST: ShelvesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("/Shelf/Create/{libraryId}")]
        public ActionResult Create([FromRoute] int libraryId, Shelf shelf)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ShelvesController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ShelvesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ShelvesController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ShelvesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
