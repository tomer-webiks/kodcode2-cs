﻿using System.ComponentModel.DataAnnotations;

namespace LibraryClassExercise.Models
{
    public class Book
    {
        public int Id { get; set; }
        public int Height { get; set; }
        public int Width { get; set; }
        public Shelf Shelf { get; set; }
    }
}
