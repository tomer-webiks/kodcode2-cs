﻿using LibraryClassExercise.Models;

namespace LibraryClassExercise.ViewModels
{
    public class LibraryShelf
    {
        public Shelf? Shelf { get; set; }
        public int? LibraryId { get; set; }
    }
}
